<style type='text/css'>
.nand_metabox { padding: 10px 10px 0px 10px; }
.nand_metabox_field { margin-bottom: 15px; width: 100%; overflow: hidden; }
.nand_metabox_field label { font-weight: bold; float: left; width: 15%; line-height: 26px; }
.nand_metabox_field .field { float: left; width: 75%; }
.nand_metabox_field input[type=text] { width: 100%; }
</style>