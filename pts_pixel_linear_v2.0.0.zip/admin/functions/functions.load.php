<?php
/**
 * Functions Load
 *
 * @package     WordPress
 * @subpackage  SMOF
 * @since       1.4.0
 * @author      Syamil MJ
 */
get_template_part( 'admin/functions/functions' );
get_template_part( 'admin/functions/functions.filters' );
get_template_part( 'admin/functions/functions.interface' );
get_template_part( 'admin/functions/functions.options' );
get_template_part( 'admin/functions/functions.admin' );