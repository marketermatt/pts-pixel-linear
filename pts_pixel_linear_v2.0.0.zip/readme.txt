﻿Pixel Linear, Copyright 2019, Pixel Theme Studio
Pixel Linear is distributed under the terms of the GNU GPL

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see https://www.gnu.org/licenses/gpl-3.0.txt.

Pixel Linear Theme bundles the following third-party resources:

Bootstrap, Copyright © 2013 Twitter, Inc.
Bootstrap is licensed under MIT
Source: http://getbootstrap.com

CMB2, Copyright © 2013
CMB2 is licensed under GPLv2
Source: https://wordpress.org/plugins/cmb2/

Theme is based on Options Framework
http://wptheming.com - GPL License

FontAwesome Icons
FontAwesome is licensed under GPL
Source: http://fortawesome.github.io/Font-Awesome/

color-picker unminified  
Source: https://github.com/evoluteur/colorpicker
iris.js unminified
Source: http://automattic.github.io/Iris/
cookie unminified
Source: https://github.com/ScottHamper/Cookies

Half Slider
Half Slider License under Apache 2.0 
Source: http://startbootstrap.com/template-overviews/half-slider/